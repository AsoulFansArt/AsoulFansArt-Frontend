<template>
<div></div>
</template>

<script>
export default {
  name: "Bottom"
}
</script>

<style scoped>

</style>
