<template>
  <div class="header">
    <Condition type="pic" @changePic="getResult" @changeLoad="getLoadStatus"></Condition>
  </div>
  <el-container id="index">

    <!-- 公共搜索头部,管理页面不显示 -->
    <!-- 主体瀑布流区域，无限滚动 -->
    <div class="container-fluid" ref="abcd" style="position: relative">
      <div class="v-waterfall-content"
           ref="abc" v-infinite-scroll="getMoreData"
           infinite-scroll-disabled="disabled"
           infinite-scroll-distance="50"
           style="position: relative"
      >
        <div
            v-for="img in waterfallList"
            :key="img.key"
            class="v-waterfall-item"
            @click="jumpBili(img)"
             :style="{top:img.top+'px',left:img.left+'px',width:imageWidth+'px',height:img.height+'px', bottom:0, position:'absolute'}">
          <!-- 图片卡片 -->
          <div class="imgnums" v-if="img.pic_url.length>1">
            <div><i class="el-icon-copy-document"></i> {{img.pic_url.length}}</div>
          </div>
          <!-- 作者卡片 -->
          <div class="picowner">
            <div><i class="el-icon-user-solid"></i>{{img.owner_name}}</div>
          </div>


          <div shadow="hover" :style="{'padding':'0px','border-radius':'10px',overflow:'hidden'}" >
            <!-- 图片懒加载 -->
            <el-image :src='img.src' class='image' :key='img.src' lazy>
              <!-- 加载前占位 -->
              <template #placeholder>
                <div  class="image-slot">
                  <div :style="{height: img.height+'px',width:imageWidth + 'px',backgroundColor:img.color}"></div>
                </div>
              </template>
              <!-- 加载失败占位 -->
              <template #error>
                <div  error class="image-slot">
                  <div :style="{height:img.height+'px',width:imageWidth + 'px',backgroundColor:img.color}"></div>
                </div>
              </template>
            </el-image>
          </div>
        </div>


      </div>
      <div v-if="isload" style="text-align: center"><i class="el-icon-loading"></i></div>
    </div>
  </el-container>
</template>

<script>
import Api from '../util/http.js'
import Condition from "./components/Condition";
import {ElMessage} from "element-plus";

export default {
  name: 'v-waterfall',
  components: {
    Condition,
  },
  data() {
    return {
      isload: false,
      isTrue:false,
      //存放计算好的数据
      waterfallList: [],
      //每一列的宽度
      imageWidth: 200,
      //多少列
      waterfallImgCol: 5,
      //右边距
      waterfallImgRight: 20,
      //下边距
      waterfallImgBottom: 10,
      //存放瀑布流各个列的高度
      waterfallColHeight: [],
      imgList: [],
      //整体左偏移量，左右相同
      colLeft: 0,
      currentPage: 0,

      //是否还有数据
      noMore: false,
      //搜索内容
      //图片详情弹窗可见
      dialogVisible: false,
      //点击的图片ID
      picId:'',
      isMobile: false,
      //随机占位色卡的颜色
      suijicolour: ['#b4ffe3','#66CDAA','#acc2e6','#d7b0d8','#95abe6','#ffc47b','#b6d288','#f49586','#bcaf7a'],
      load_params:{
        page:0,
        tag_id: 0,
        sort: 1,
        part: 0,
        rank: 0,
        ctime:0,
      },
      isWebp:true,
    };
  },
  created() {
    //初始就加载数据
    this.getMoreData();
  },
  mounted() {
    this.$notify({
      title: '提示',
      dangerouslyUseHTMLString: true,
      message:  '<p>图片来源bilibili.com</p>图片右下角为原作者B站ID'
    });

    let ua = navigator. userAgent. toLowerCase();
    console.log(ua)
    try {
      let chrome = ua.indexOf("chrome") > -1
      if (!chrome){
        let isSafari = ua.indexOf("safari") > -1
        if (isSafari){
          let re = new RegExp(`version\\/(.*?)\\.`)
          if (parseInt(re.exec(ua)[1]) < 14){
            alert("请更新safari版本，或者尝试更新浏览器")
          }
        }
      }

    }catch (e){
      console.log(e)
    }



    window.scrollTo(0, 0)
    //计算可视区域能够容纳的最大列数,向下取整
    let fullWidth = this.$refs.abcd.clientWidth;
    if (fullWidth > 1500) {
      this.imageWidth = 280;
    } else if (fullWidth < 800) {
      this.isMobile= true;
      this.imageWidth = 160;
    }
    let maxColNum = Math.floor(fullWidth / (this.imageWidth + this.waterfallImgRight));
    //console.log('可视宽度：' + fullWidth + ',列数：' + maxColNum);
    if (maxColNum == 0) {
      maxColNum = 1;
    }
    let contentWhith = (this.imageWidth + this.waterfallImgRight) * maxColNum;
    if ((fullWidth - contentWhith) < (this.imageWidth * 0.8)) {

      contentWhith = (this.imageWidth + this.waterfallImgRight) * maxColNum;
    }

    //console.log('计算列数：' + maxColNum);

    //获取左边距
    this.colLeft = (fullWidth - contentWhith) / 2;
    if (maxColNum == 1) {
      maxColNum = 2;
    }
    this.waterfallImgCol = maxColNum;
    //console.log('总宽度：' + fullWidth + ',内容宽度：' + contentWhith + '左偏移：' + this.colLeft);
    //初始化偏移高度数组
    this.waterfallColHeight = new Array(this.waterfallImgCol);
    for (let i = 0; i < this.waterfallColHeight.length; i++) {
      this.waterfallColHeight[i] = 0;
    }
  },
  methods: {
    getLoadStatus(bool){
      this.isload = bool
    },
    getResult(data){
      console.log("getResult")
      this.waterfallList = [];
      this.currentPage = 1;
      for (let i = 0; i < this.waterfallColHeight.length; i++) {
        this.waterfallColHeight[i] = 0;
      }
      this.load_params = data.load_params;
      this.imgPreloading(data.response);
    },
    jumpBili(item){
      //console.log(String(item[0].dy_id))
      window.open(`https://t.bilibili.com/${item.dy_id}?tab=2`)
    },
    descFilter(text){
      let filter_arr = ["@嘉然今天吃什么","@向晚大魔王" ,"@A-SOUL_Official","@乃琳Queen","@贝拉Kira","@珈乐Carol"
        ,"@贝拉kira","@贾布加布","#A-SOUL二创激励计划#","@Asoul二创计画", "@DJ鱼谷" ]
      for (let item of filter_arr){
        text = text.replace(item, "")
      }
      let re = new RegExp('#(.*?)#', 'gm');
      text = text.replace(re, "")
      re = new RegExp('\\[(.*?)\\]', 'gm');
      text = text.replace(re, "")
      if (text.length > 10){
        text = text.substr(0,10) + "..."
      }
      return text
    },
    //搜索，从其他组件传值放到$store中的
    search() {
      //点击查询重置页数和瀑布流每列高度
      this.currentPage = 1;
      for (let i = 0; i < this.waterfallColHeight.length; i++) {
        this.waterfallColHeight[i] = 0;
      }
      this.waterfallList = [];
      this.getMoreData();
    },
    // 获取数据
    getMoreData() {


      //console.log('查询参数：' + search);

      //console.log('查询参数：' + this.currentPage);
      // if(param.pageNo>10){this.noMore=true;return;}
      this.isload = true
      this.load_params.page++
      Api._getPic(
          this.load_params
        ).then((res) => {
          this.isload = false
          if (res.data.message == "没有更多数据"){
            //alert(res.data.message)
            ElMessage.warning({
              message: '没有更多了......',
              type: 'warning'
            });
            return
          }

          //console.log(res.data[0].pic_url)
          if (res.data[0].pic_url.length == 0) {
            this.noMore = true;
          } else {
            this.imgPreloading(res.data);
            this.noMore = false;
          }

        })


    },
    //图片预加载
    imgPreloading(moreList) {

      //console.log(listLen, moreList)
      for (let i = 0; i < moreList.length; i++) {
        let imgData = moreList[i];
        moreList[i] = moreList[i].pic_url[0]


        if(moreList[i].img_src.indexOf('http') > 0){
          continue;
        }
        let aImg = new Image();
        //图片渲染列表，先把高宽和占位颜色赋值直接push到waterfallList，图片的实际url等图片加载上了在赋值
        imgData.height = this.imageWidth / moreList[i].img_width * moreList[i].img_height;
        //console.log('第' + i + '张图片的高度是：'+imgData.height );
        imgData.id = moreList[i].id;
        //获取随机占位背景色
        imgData.color=this.suijicolour[i%9];
        this.waterfallList = [...this.waterfallList,imgData];
        let webp_w = parseInt(this.imageWidth * 1.5) ;
        let webp_h =parseInt(imgData.height * 1.5) ;
        if (webp_w < 200){
          webp_w = webp_w * 2
          webp_h = webp_h * 2
        }
        let suffix = `@${webp_w}w_${webp_h}h_1e_1c.webp`
        aImg.onload = () => {

            aImg.src =  `${moreList[i].img_src}${suffix}`;
          //console.log(e)
        };
        this.rankImg(imgData);
        imgData.src =  `${moreList[i].img_src}${suffix}`;
      }
    },
    //瀑布流布局核心，计算高度和左偏移
    rankImg(imgData) {
      let {
        imageWidth,
        waterfallImgRight,
        waterfallImgBottom,
        waterfallColHeight,
        colLeft
      } = this;
      //找出当前最短列的索引
      let minIndex = waterfallColHeight.indexOf(Math.min.apply(null, waterfallColHeight));
      //获取最短列底部高度，既下一张图片的顶部高度
      imgData.top = waterfallColHeight[minIndex];
      //计算左侧偏移，最短列索引*（右边距+列宽度）
      imgData.left = minIndex * (waterfallImgRight + imageWidth) + colLeft;
      //改变当前列高度
      waterfallColHeight[minIndex] += imgData.height + waterfallImgBottom;
      // console.log(imgData.key + ":" + JSON.stringify(imgData));
      // console.log(waterfallColHeight);
    },
    //打开图片详情
    openDialog(picId){
      this.picId = picId;
      this.dialogVisible = true;
      // this.$refs.detailWin.getInfo();
    },
    opmethod(){
      //打开详情页的回调，延迟加载详情页的数据，避免子组件的方法没找到
      setTimeout(() => {
        this.$refs.detailWin.getInfo();
      }, 10);
    },
    closedialog(){
      //关闭弹窗
      this.dialogVisible = false;
    }
  },
  computed: {
    disabled() {
      return this.noMore;
    }
  },

};

</script>

<style lang="scss" scoped>
.image{

  box-shadow: 0 0 8px rgba(0,0,0,.175)!important;
  border-radius: 16px;
  transition: transform .45s ease-in-out;

}
.v-waterfall-item{
  box-shadow: 0 0 8px rgba(0,0,0,.175)!important;
  overflow: hidden;
  transition: none !important;
  position: relative;
  z-index:10;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 16px;
  background-repeat: no-repeat;
  background-size: cover;

  background-position: center center;
  .img-title{
    transition: opacity .25s ease-in-out;
    opacity: 0;
    bottom: 50%;
    transform: translateY(50%);
  }
  ::after{
    content: "";
    position: absolute;
    text-align: center;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 0;
    width: 100%;
    border-radius: 16px;
    box-sizing: border-box;
    transition: 200ms;
    height: 100%;
    background-color: rgba(0,0,0,0);
    background: {
      position: center;
      repeat: no-repeat;
      size: cover;
    }
  }

  &:hover{
    .img-title{
      opacity: 1;
    }
    .image{
      transform: scale(1.1,1.1);
    }

  }

}
.header{
  margin-top: 2rem;
}
.imgnums{
  position: absolute;
  z-index: 90;
  top: 8px;
  right: 10px;
  border-radius: .375rem;
  background: rgba(99,99,99,.5);
  color: white;
  font-size: x-small;
  padding: .35rem .375rem;
}
.picowner{
  position: absolute;
  z-index: 90;
  bottom: 8px;
  right: 10px;
  border-radius: .375rem;
  background: rgba(99,99,99,.5);
  color: white;
  font-size: x-small;
  padding: .35rem .375rem;
}
.v-waterfall-content{
  width: 100%;
}
</style>

