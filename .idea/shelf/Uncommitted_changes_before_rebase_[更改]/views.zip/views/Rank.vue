<template>
  <Condition @changeMs="getResult" @changeLoad="getLoadStatus"></Condition>
  <!--主界面-->
  <div class="container-fluid">
    <div
        ref="abc"
        style="position: relative"
        v-infinite-scroll="load"
        infinite-scroll-distance="10"
        infinite-scroll-disabled="disabled"
        class="main row justify-content-center"
        v-loading="isload"
    >
        <div
            v-for="(item,index) in response"
            v-bind:key="index"
            class="main-item col-sm-12 col-md-12 col-lg-12 m-1"
        >


          <div :style="{width:'70rem', overflow:'hidden'}">

            <div class="col-rank" @click="jumpBili(item.bvid)">
              <el-image
                  :src="item.pic"
                  :style="{width: mainStyle.col_rank_image_width}"
                  alt="" class="image" lazy>

              </el-image>
              <div class="col-info">
                <div class="col-title">{{item.title}}</div>
                <div class="col-data">
                  <div class="col-rank-item" v-if="item.his_rank">
                    <i class="el-icon-trophy"></i>全站排行榜最高第{{item.his_rank}}名
                  </div>
                  <div class="col-rank-item" v-if="item.now_rank">
                    <i class="el-icon-trophy"></i>当前排行榜第{{item.now_rank}}名
                  </div>

                  <div><span><i class="el-icon-user-solid"></i>{{item.owner_name}}</span></div>
                  <span><i class="el-icon-video-play"></i>{{g._changeBillionToCN(item.stat_view)}}</span>
                  <span class="col-data-item"><i class="el-icon-postcard"></i>{{g._changeBillionToCN(item.stat_danmaku)}}</span>
                  <span class="col-data-item"><i class="el-icon-time"></i>{{g._timestampToTime(item.pubdate)}}</span>
                  <span v-if="!isMobile">
                    <span class="col-data-item"><i class="iconfont icon-0_like1" style="font-size: xx-small;"></i>{{g._changeBillionToCN(item.stat_like)}} </span>
                    <span class="col-data-item"><i class="el-icon-coin"></i>{{g._changeBillionToCN(item.stat_coin)}}</span>
                    <span class="col-data-item"><i class="el-icon-star-off"></i>{{g._changeBillionToCN(item.stat_favorite)}}</span>
                    <span class="col-data-item"><i class="el-icon-chat-line-square"></i>{{g._changeBillionToCN(item.stat_reply)}}</span>
                    <span class="col-data-item"><i class="el-icon-share"></i>{{g._changeBillionToCN(item.stat_share)}}</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>

    <p v-loading="loading" v-if="loading" style="text-align: center"><i class="el-icon-loading"></i></p>
    <p v-if="!loading" style="text-align: center;padding-bottom: 5px">
      <el-button
          plain
          :disabled="noMore"
          type="primary" @click="nextPage"
          lazy
      >下一页<i class="el-icon-arrow-right el-icon--right"></i></el-button></p>
  </div>
</template>

<script>
import Api from '../util/http.js'
import Condition from "./components/Condition";
import g from '../util/general'
import {ElMessage} from "element-plus";

export default {
  name: "Rank",
  components:{
    Condition
  },
  data() {
    return {
      isload:false,
      loading:false,
      noMore:false,
      g:g,
      mainStyle:{},
      response: [],
      isMobile: false,
      load_params:{
        page:0,
        tag_id: 0,
        sort: 2,
        part: 0,
        rank: 0,
        ctime:0,
      },
    }
  },
  methods:{
    getLoadStatus(bool){
      this.isload = bool
    },
    getResult(data){
      this.noMore = false
      this.response = data.response;
      this.load_params = data.load_params;
    },
    load () {
      this.loading = true
      this.load_params.page++;
      try {
        Api._getBV(this.load_params).then((res) => {
          this.loading = false
          if (res.data.message === "没有更多数据") {
            ElMessage.warning({
              message: '没有更多了......',
              type: 'warning'
            });
            this.noMore=true//alert("没有更多数据")
            return}
          this.noMore = false
          this.response = [...this.response,...res.data]

        })
      }catch (e){
        console.log(e)
      }


    },

    jumpBili(bvid){
      window.open(`https://www.bilibili.com/video/${bvid}`)
    },
    _isMobile() {
      return navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i)
    },

    nextPage(){
      this.load()
    }

  },
  computed: {

    disabled () {
      return this.noMore || this.loading
    }
  },
  /*
* 初始化数据
*
* */
  mounted() {
    Api._getNotification().then((res)=>{
          if(res.data.length > 0){
            for (let item of res.data){
              console.log(item)
              setTimeout(()=>{
                this.$notify({
                  title: '公告',
                  dangerouslyUseHTMLString: true,
                  message:  item.content,
                  duration: 0
                },1000);
              })


            }
          }

        }
    )
    window.scrollTo(0, 0)
    let fullWidth = this.$refs.abc.clientWidth;
    if (this._isMobile()){
      this.isMobile = true
      if (fullWidth > 700) {
        this.isMobile = false
        this.mainStyle = {
          col_rank_image_width:"10rem"
        }
      } else{
        this.mainStyle = {
          col_rank_image_width:"40%"
        }
      }

    }else{
      this.isMobile = false
      this.mainStyle = {
        col_rank_image_width:"10rem",
      }
    }
    this.load()
  },
}
</script>

<style lang="scss" scoped>
.el-card{
  height: 100%;
}





.col-rank{
  width: 100%;
  display: flex;
  border-bottom:1px solid #b8c0cc;
  padding-bottom: 5px;
  position:relative;
  height: 100%;
  .image {
    border-radius: 5px;
    object-fit: cover;
  }
  .col-info{
    position:relative;
    width:60%;
    height: 100%;
    .col-title{
      font-size: smaller;
      flex:1;
      overflow: hidden;
      height: 50%;
    }
    .col-data{
      position:absolute;
      font-size: x-small;
      bottom: 0;
      .col-data-item{
        margin-left: 5px;
      }
    }
  }
  .col-score{
    text-align: center;
    width: 5rem;
    margin-top: 1rem;
    position: absolute;
    right: 1rem;
  }
}


.col-rank-item{
  color:#ea9999;
  font-size: xx-small;
}
.col-tags{
  display: flex;
  justify-content: space-between;
}
.col-sel{
  display: flex;
  justify-content: center;
  margin-bottom: 5px;
}
.el-select{
  border: 0;
  margin-right: 2px;
  margin-left:0;
}

.col-tag-item{
  margin: 5px;
}
.el-row{
  justify-content: center;
  flex-direction:column;
}

.main-item{
  display: flex;
  justify-content: center;
}


</style>
